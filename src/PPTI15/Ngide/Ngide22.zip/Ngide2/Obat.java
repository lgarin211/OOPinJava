package PPTI15.Ngide.Ngide2;

import javax.swing.InputMap;

public class Obat {
    String NamaObat;
    String KandunganObat;
    String DosisObat;
    String LamaPakai;
    String Keterangan;
    
    public Obat(String NamaObat, String KandunganObat, String DosisObat, String LamaPakai, String Keterangan){
        this.NamaObat = NamaObat;
        this.KandunganObat = KandunganObat;
        this.DosisObat = DosisObat;
        this.LamaPakai = LamaPakai;
        this.Keterangan = Keterangan;
    }

}
