package PPTI15.Ngide.Ngide2;

public class ListFasilitas {
    
    public static void superVIP(){
        System.out.println("=========================\n");
        System.out.println("Fasilitas Kamar Super VIP");
        System.out.println("=========================\n");
        System.out.println("Tempat Tidur Elektrik");
        System.out.println("AC");
        System.out.println("TV LCD 32");
        System.out.println("Meja Makan Pasien");
        System.out.println("Sofa Bed & Meja");
        System.out.println("Kamar Mandi (Panas / Dingin)");
        System.out.println("Credenza");
        System.out.println("Telepon");
        System.out.println("2 Kabinet");
        System.out.println("Microwave");
        System.out.println("Kulkas");
        System.out.println("1 Set Meja Makan Keluarga");
    }

    public static void VIP(){
        System.out.println("===================\n");
        System.out.println("Fasilitas Kamar VIP");
        System.out.println("===================\n");
        System.out.println("Tempat Tidur Elektrik");
        System.out.println("AC");
        System.out.println("TV LCD 32");
        System.out.println("Kulkas Minibar");
        System.out.println("Meja Makan Pasien");
        System.out.println("Sofa Bed & Meja");
        System.out.println("Kamar Mandi (Panas / Dingin)");
        System.out.println("Telepon");
    }

    public static void kelas1(){
        System.out.println("=======================\n");
        System.out.println("Fasilitas Kamar Kelas 1");
        System.out.println("=======================\n");
        System.out.println("2 Tempat Tidur Pasien");
        System.out.println("AC");
        System.out.println("TV LCD 32");
        System.out.println("2 Meja Makan Pasien");
        System.out.println("2 Kursi Tunggu");
        System.out.println("Kamar Mandi (Panas / Dingin)");
    }

    public static void kelas2(){
        System.out.println("=======================\n");
        System.out.println("Fasilitas Kamar Kelas 2");
        System.out.println("=======================\n");
        System.out.println("3 Tempat Tidur Pasien");
        System.out.println("3 Tempat Tidur Pasien");
        System.out.println("AC");
        System.out.println("TV LCD 32");
        System.out.println("3 Meja Makan Pasien");
        System.out.println("3 Kursi Tunggu");
        System.out.println("Kamar Mandi (Panas / Dingin)");
    }
}