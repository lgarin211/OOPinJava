package PPTI15.Ngide.Ngide2.Support;

public class bin {
    public static void Hospital(){
        // System.out.println("                        %%%%");                       
        // System.out.println("                    %%%%%%%%%%%");                   
        // System.out.println("                %%%%%%%%%%%%%%%%%%%");               
        // System.out.println("            %%%%%%%%%%%%%%%%%%%%%%%%%%%");           
        // System.out.println("         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");       
        // System.out.println("     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");    
        // System.out.println(" %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        // System.out.println("  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        // System.out.println("       %%%%%%%%                     %%%%%%%%");      
        // System.out.println("       %%%%%%%         %%%%          %%%%%%%");      
        // System.out.println("       %%%%%%%      %%%%%%%%%%      %%%%%%%%");      
        // System.out.println("       %%%%%%%%     %%%%%%%%%%     %%%%%%%%%");      
        // System.out.println("       %%%%%%%%%%%     %%%%      %%%%%%%%%%%");      
        // System.out.println("       %%%%%%%%%%%%%%        *%%%%%%%%%%%%%%");      
        // System.out.println("       %%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%");      
        // System.out.println("       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");      
        // System.out.println("       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");  
    }
}
