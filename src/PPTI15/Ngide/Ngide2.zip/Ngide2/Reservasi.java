package PPTI15.Ngide.Ngide2;

public class Reservasi {
    Reservasi(){
        System.out.println("Reservasi");
    }

    
}
