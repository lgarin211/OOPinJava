package PPTI15.Ngide.Ngide2;

public class Admin {
    
}
